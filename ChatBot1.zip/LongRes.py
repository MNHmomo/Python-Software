import random

R_EATING = "I don't like eating anything because I'm obviously a bot"
FAV_GAME = "My favorite game is the Stanley Parable"
LIST_GAME = "I like Resident Evil and Spiderman"

def unknown():
    response = ['Could you please re-phrase that',
                '...'
                'What do you mean?',
                'What does that mean?',
                'I don\'t understand'][random.randrange(5)]
    return response
